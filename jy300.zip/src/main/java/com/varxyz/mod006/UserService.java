package com.varxyz.mod006;

public class UserService {
	
	public void addUser(User user) {
		System.out.println("성공");
	}

	public static UserService getInstance() {
		return null;
	}
}
