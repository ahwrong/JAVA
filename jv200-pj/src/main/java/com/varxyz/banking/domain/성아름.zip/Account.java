package com.varxyz.banking.domain;
/**
 * ���� ����
 * @author Administrator
 * 
 * Lucky Num;
 */
public class Account {
	protected String accountNum;
	protected double balance;
	
	public void deposite(double amount) {
		this.balance += amount;
	}
}
