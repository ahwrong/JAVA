package com.varxyz.jv251.exception;

@SuppressWarnings("serial")
public class EntityNotFoundException extends Exception {
   public EntityNotFoundException(String msg) {
      super(msg);
   }
}
